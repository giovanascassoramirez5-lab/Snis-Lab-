SEGOJMEIT · SNIS Laboratorio
Versión funcional local.
- Registro diario por orden médica.
- Edad y sexo.
- Seguro editable (por defecto Syncronia).
- Pruebas agrupadas por grupo SNIS.
- Consolidado diario con filtros.
- Exportación CSV.
- Catálogo editable con precios por seguro.
- Cotización conservada como módulo.
- Cargo de atención a domicilio inicial: Bs 40.
- Precios iniciales cargados: hemograma 45.50; glicemia 32.50; creatinina 32.50; TSH 100; HbA1c 104; gasometría arterial 300.
Los demás análisis quedan en 0.00 hasta cargar el tarifario completo de 511 análisis.
